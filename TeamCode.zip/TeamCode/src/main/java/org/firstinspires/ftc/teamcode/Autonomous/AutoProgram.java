package org.firstinspires.ftc.teamcode.Autonomous;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.Components.Robot;

@Autonomous(name= "AutoProgram")

public class AutoProgram extends LinearOpMode {
    @Override
    public void runOpMode() {
        Robot robot = new Robot(this);
        ElapsedTime runtime = new ElapsedTime();
        robot.setPosition(0,0,0);
        //to calculate how many times robot can cycle before time robot runs out of time
        double autoCycleTime=0;
        double cycleStartTime=0;
        waitForStart();
        runtime.reset();
        //check each element and intake if it is red
        for(int i=0;i<3;i++) {
            robot.goToPosition(24, -24+i*24, 0, 0.8);
            if (robot.elementIsRed()) {
                robot.startIntake();
                //don't have to stop at the end for anything so use withoutStop to save time
                robot.goToPositionWithoutStop(30,-24+i*24,0,0.5);
                break;
            }
        }
        //go to deposit area and turn -90 degrees to make the depositer face the box
        robot.goToPosition(72,48, -90,1.0);
        //deposit red cylinder
        robot.depositElements(1);
        //start calculation for time one cycle takes
        cycleStartTime = runtime.seconds();
        //first cycle
        //go to area in front of depot
        //use goToPositionWithoutStop to save time
        robot.goToPositionWithoutStop(100,-48, -90,1.0);
        //pick up first element
        robot.startIntake();
        robot.goToPositionWithoutStop(100,-58,-90,0.6);
        //exit depot so human player can place next element might need sleep after
        robot.goToPositionWithoutStop(100,-48,-90,0.6);
        //pick up second element
        robot.goToPositionWithoutStop(100,-58,-90,0.6);
        //return to deposit box
        robot.goToPosition(72,48, -90,1.0);
        //deposit two elements
        robot.depositElements(2);
        //calculate cycle time
        autoCycleTime=runtime.seconds()-cycleStartTime;
        //keep cycling until out of time
        while(30-runtime.seconds()>autoCycleTime){
            //go to area in front of depot
            robot.goToPositionWithoutStop(100,-48, -90,1.0);
            //pick up first element
            robot.startIntake();
            robot.goToPositionWithoutStop(100,-58,-90,0.6);
            //exit depot so human player can place next element might need sleep after
            robot.goToPositionWithoutStop(100,-48,-90,0.6);
            //pick up second element
            robot.goToPositionWithoutStop(100,-58,-90,0.6);
            //return to deposit box
            robot.goToPosition(72,48, -90,1.0);
            //deposit two elements
            robot.depositElements(2);
        }
        //park(don't know what teleOp missions are, but if i knew would try get to the optimal position for teleOp here & park)
        robot.goToPosition(48,48,-90,0.8);
        stop();
    }
}
