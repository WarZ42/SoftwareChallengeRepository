package org.firstinspires.ftc.teamcode.Components;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;

public class Depositer {
    private LinearOpMode op = null;
    private DcMotor depositMotor;
    private Servo depositServo;
    //random tick value for the two lines below because don't have actual robot and not sure how mechanism works
    int ticksForExtendDepositMotor = 1000;
    double rotationForDepositServo = 1.0;

    // initialization of depositer motor & servo
    public Depositer(LinearOpMode opMode){
        op = opMode;
        depositMotor = opMode.hardwareMap.dcMotor.get("DepositMotor");
        depositMotor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        depositServo = opMode.hardwareMap.servo.get("DepositServo");
    }
    // im not sure how the depositer attachment works but I remember stuff about a motor powering a linear slide and a servo,
    // so I just guessed the mechanism for this function
    public void depositElements(int numOfElements) {
        depositMotor.setTargetPosition(ticksForExtendDepositMotor);
        depositMotor.setPower(0.8);
        depositMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        //sleep to wait for motor to get to target position
        op.sleep(500);
        for(int i=0;i<numOfElements; i++){
            depositServo.setPosition(rotationForDepositServo);
            //sleep to wait for servo to get to target position
            op.sleep(200);
            depositServo.setPosition(0);
        }
        depositMotor.setTargetPosition(0);
        depositMotor.setPower(0.8);
        depositMotor.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        //sleep to wait for motor to get to target position
        op.sleep(500);
    }

}
