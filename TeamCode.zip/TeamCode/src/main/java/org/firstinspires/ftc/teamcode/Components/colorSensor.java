package org.firstinspires.ftc.teamcode.Components;

import android.graphics.Color;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.DistanceSensor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.ElapsedTime;

public class colorSensor {
    private LinearOpMode op = null;
    private HardwareMap hardwareMap = null;
    private ElapsedTime period = new ElapsedTime();

    ColorSensor intakeColorSensor;

    public colorSensor(LinearOpMode opMode) {
        op = opMode;
        hardwareMap = op.hardwareMap;
        intakeColorSensor = hardwareMap.get(ColorSensor.class, "intakeColorSensor");
    }

    //detects if red
    public boolean elementIsRed() {
        boolean red = false;
        //estimated rgb values for red cylinder
        if(intakeColorSensor.red()>160&&intakeColorSensor.green()<120&&intakeColorSensor.blue()<120){
            red=true;
        }

        return red;
    }
}
