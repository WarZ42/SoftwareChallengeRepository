package org.firstinspires.ftc.teamcode.Components;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.util.ElapsedTime;

public class Robot {

    private LinearOpMode op = null;
    public final static boolean isCorgi = true;

    // Hardware Objects

    private Intake intake = null;
    private Depositer depositer = null;
    private Chassis chassis = null;
    private colorSensor colorSensor = null;

    public Robot(LinearOpMode opMode) {
        op = opMode;

        intake = new Intake(op);
        depositer = new Depositer(op);
        chassis = new Chassis(op);
        colorSensor = new colorSensor(op);

    }

    public void setPosition(float x, float y, float newAngle) {
        chassis.setPosition(x, y, newAngle);
    }

    public void stopAllMotors() {
        chassis.stopAllMotors();
    }

    public void goToPosition(double y, double x, double a, double power) {
        chassis.goToPosition(y, x, a, power);
    }

    public void goToPositionWithoutStop(double y, double x, double a, double power) {
        chassis.goToPositionWithoutStop(y, x, a, power);
    }

    public void turnInPlace(double target, double power) {
        chassis.turnInPlace(target, power);
    }

    public boolean elementIsRed() {
        return colorSensor.elementIsRed();
    }

    public void depositElements(int numOfElements) {
        depositer.depositElements(numOfElements);
    }

    public void startIntake() {
        intake.startIntake();
    }

    public void reverseIntake() {
        intake.reverseIntake();
    }

    public void stopIntake() {
        intake.stopIntake();
    }


}

